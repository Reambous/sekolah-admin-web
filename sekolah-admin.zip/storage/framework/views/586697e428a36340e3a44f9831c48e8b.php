<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\laragon\www\sekolah-admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>