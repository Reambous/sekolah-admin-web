<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-white min-h-screen font-sans text-gray-900">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">

            
            <div class="bg-white border-2 border-gray-200 p-8 shadow-sm relative">

                
                <div class="border-b-4 border-gray-900 pb-4 mb-8">
                    <h2 class="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-1">
                        Tambah Kegiatan Kesiswaan
                    </h2>
                    <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">
                        Input laporan baru terkait kegiatan kesiswaan
                    </p>
                </div>

                <div class="p-0 text-gray-900">

                    
                    <?php if($errors->any()): ?>
                        <div class="mb-6 bg-red-50 border-l-4 border-red-600 p-4 text-red-800">
                            <strong class="font-black uppercase text-xs tracking-wide block mb-1">Ups! Ada kesalahan
                                input:</strong>
                            <ul class="list-disc list-inside text-sm font-medium">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('kesiswaan.kegiatan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        
                        <div class="mb-6">
                            <label for="tanggal"
                                class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                                Tanggal Kegiatan
                            </label>
                            <input type="date" name="tanggal" id="tanggal" value="<?php echo e(old('tanggal')); ?>"
                                class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3">
                        </div>

                        
                        <div class="mb-6">
                            <label for="nama_kegiatan"
                                class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                                Nama Kegiatan
                            </label>
                            <input type="text" name="nama_kegiatan" id="nama_kegiatan"
                                placeholder="Contoh: Perbaikan AC Ruang Guru" value="<?php echo e(old('nama_kegiatan')); ?>"
                                class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3 placeholder-gray-400">
                        </div>

                        
                        <div class="mb-8">
                            <label for="refleksi"
                                class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                                Refleksi / Keterangan Evaluasi
                            </label>
                            <textarea name="refleksi" id="refleksi" rows="6"
                                placeholder="Tuliskan kendala, solusi, atau hasil kegiatan di sini secara rinci..."
                                class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3 placeholder-gray-400"><?php echo e(old('refleksi')); ?></textarea>
                            <p class="text-[10px] text-gray-400 font-bold uppercase mt-2 tracking-wide">* Data ini akan
                                dikunci setelah divalidasi oleh Admin.</p>
                        </div>

                        
                        <div class="flex items-center justify-between pt-6 border-t-2 border-gray-100">
                            <a href="<?php echo e(route('kesiswaan.kegiatan.index')); ?>"
                                class="text-xs font-bold text-gray-500 uppercase tracking-widest hover:text-black hover:underline transition">
                                Batal
                            </a>
                            <button type="submit"
                                class="bg-gray-900 text-white px-6 py-3 text-xs font-black uppercase tracking-wider hover:bg-blue-900 transition shadow-sm border-b-4 border-black hover:border-blue-950 transform hover:-translate-y-0.5">
                                Simpan Laporan
                            </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sekolah-admin\resources\views/guru/kesiswaan/kegiatan/create.blade.php ENDPATH**/ ?>