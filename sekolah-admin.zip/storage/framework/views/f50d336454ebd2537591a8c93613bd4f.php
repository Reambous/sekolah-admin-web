<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-white min-h-screen font-sans text-gray-900">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white border-2 border-gray-200 p-8 shadow-sm relative">

                <div class="border-b-4 border-gray-900 pb-4 mb-6">
                    <h2 class="text-2xl font-black text-gray-900 uppercase tracking-tighter">
                        Edit Komentar
                    </h2>
                </div>

                <form action="<?php echo e(route('berita.comment.update', $komentar->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                    <div class="mb-6">
                        <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                            Isi Komentar
                        </label>
                        <textarea name="isi_komentar" rows="4" required
                            class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3"><?php echo e($komentar->isi_komentar); ?></textarea>
                    </div>

                    <div class="flex justify-between items-center">
                        <a href="<?php echo e(route('berita.show', $komentar->berita_id)); ?>"
                            class="text-xs font-bold text-gray-500 uppercase hover:text-black hover:underline">
                            Batal
                        </a>
                        <button
                            class="bg-gray-900 text-white px-5 py-2 text-xs font-black uppercase tracking-wider hover:bg-blue-900 transition shadow-sm border-b-4 border-black hover:border-blue-950">
                            Update Komentar
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sekolah-admin\resources\views/berita/edit_comment.blade.php ENDPATH**/ ?>