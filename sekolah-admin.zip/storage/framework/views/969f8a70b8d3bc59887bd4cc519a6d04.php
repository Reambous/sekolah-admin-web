<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

    
    <style>
        #tampilan-hp {
            display: block;
        }

        #tampilan-laptop {
            display: none;
        }

        @media (min-width: 768px) {
            #tampilan-hp {
                display: none !important;
            }

            #tampilan-laptop {
                display: block !important;
            }
        }
    </style>

    <div class="py-8 bg-white min-h-screen font-sans text-gray-900">
        <div class="max-w-[95%] mx-auto">

            
            <div
                class="border-b-4 border-gray-900 mb-8 pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h2 class="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-1">
                        Riwayat Perizinan
                    </h2>
                    <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">
                        Daftar pengajuan ijin dan cuti guru/staf
                    </p>
                </div>

                
                <div class="flex flex-wrap items-center gap-2">
                    <?php if(Auth::user()->role == 'admin'): ?>
                        
                        <div class="flex items-center gap-2 border-r border-gray-300 pr-3 mr-1">
                            <input type="checkbox" id="select-all"
                                class="w-5 h-5 border-2 border-gray-400 text-gray-900 focus:ring-gray-900">
                            <button type="button" id="btn-hapus-massal"
                                class="bg-red-600 text-white px-4 py-2 text-xs font-bold uppercase tracking-wider hover:bg-red-700 transition shadow-sm">
                                Hapus Terpilih
                            </button>
                        </div>

                        
                        <a href="<?php echo e(route('ijin.export')); ?>"
                            class="bg-green-700 text-white px-4 py-2 text-xs font-bold uppercase tracking-wider hover:bg-green-800 transition shadow-sm flex items-center gap-2">
                            <span>📥</span> Export Excel
                        </a>
                    <?php endif; ?>

                    
                    <a href="<?php echo e(route('ijin.create')); ?>"
                        class="bg-gray-900 text-white px-5 py-2 text-xs font-bold uppercase tracking-wider hover:bg-yellow-500 hover:text-black transition shadow-lg transform hover:-translate-y-0.5">
                        + Ajukan Ijin
                    </a>
                </div>
            </div>

            
            <?php if(session('success')): ?>
                <div
                    class="mb-6 bg-green-50 border-l-4 border-green-600 p-4 text-green-800 text-sm font-bold flex items-center gap-2 shadow-sm">
                    <span>✅</span> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div
                    class="mb-6 bg-red-50 border-l-4 border-red-600 p-4 text-red-800 text-sm font-bold flex items-center gap-2 shadow-sm">
                    <span>⚠️</span> <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            
            <div id="tampilan-hp" class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $data_ijin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div
                        class="bg-white border-2 border-gray-100 p-5 shadow-sm relative group hover:border-blue-200 transition">

                        
                        <div class="flex justify-between items-start mb-3 border-b border-gray-100 pb-2">
                            <div>
                                <div class="text-xs font-black text-blue-700 uppercase tracking-wide">
                                    <?php echo e(\Carbon\Carbon::parse($item->tanggal)->translatedFormat('d M Y')); ?>

                                </div>
                                <div class="text-[10px] text-gray-500 font-bold uppercase mt-1">
                                    <?php if($item->jam_mulai && $item->jam_selesai): ?>
                                        🕒 <?php echo e(\Carbon\Carbon::parse($item->jam_mulai)->format('H:i')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($item->jam_selesai)->format('H:i')); ?> WIB
                                    <?php else: ?>
                                        🕒 1 HARI PENUH
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <?php if($item->status == 'pending'): ?>
                                <span
                                    class="px-2 py-1 text-[10px] font-bold uppercase tracking-wide border bg-yellow-50 text-yellow-700 border-yellow-200">⏳
                                    Menunggu</span>
                            <?php elseif($item->status == 'disetujui'): ?>
                                <span
                                    class="px-2 py-1 text-[10px] font-bold uppercase tracking-wide border bg-green-50 text-green-700 border-green-200">✅
                                    Disetujui</span>
                            <?php else: ?>
                                <span
                                    class="px-2 py-1 text-[10px] font-bold uppercase tracking-wide border bg-red-50 text-red-700 border-red-200">❌
                                    Ditolak</span>
                            <?php endif; ?>
                        </div>

                        
                        <div class="mb-4">
                            <div class="text-xs font-bold text-gray-500 uppercase mb-1 truncate">
                                Guru: <span class="text-black"><?php echo e($item->nama_guru); ?></span>
                            </div>
                            <p class="text-gray-600 text-sm italic bg-gray-50 p-3 border-l-2 border-gray-300 truncate">
                                "<?php echo e($item->alasan); ?>"
                            </p>
                        </div>

                        
                        <div class="flex justify-between items-center mb-4">
                            <?php if($item->bukti_foto): ?>
                                <a href="<?php echo e(asset('storage/' . $item->bukti_foto)); ?>" target="_blank"
                                    class="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-1 border border-indigo-200 uppercase hover:bg-indigo-100">
                                    📷 Lihat Bukti
                                </a>
                            <?php else: ?>
                                <span
                                    class="text-[10px] font-bold text-gray-400 bg-gray-50 px-2 py-1 uppercase border border-gray-200">
                                    Tanpa Bukti
                                </span>
                            <?php endif; ?>

                            <?php if(Auth::user()->role == 'admin'): ?>
                                <div class="z-10">
                                    <input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>"
                                        class="item-checkbox w-6 h-6 border-2 border-gray-300 text-red-600 focus:ring-red-500 rounded-none">
                                </div>
                            <?php endif; ?>
                        </div>

                        
                        <div class="flex flex-wrap gap-2 pt-3 border-t border-gray-100">
                            <a href="<?php echo e(route('ijin.show', $item->id)); ?>"
                                class="text-xs bg-gray-900 text-white px-3 py-1.5 font-bold uppercase tracking-wider hover:bg-blue-700">
                                Detail
                            </a>

                            <?php if(Auth::user()->role == 'admin' && $item->status == 'pending'): ?>
                                <form action="<?php echo e(route('ijin.approve', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button type="submit"
                                        class="text-xs bg-green-600 text-white px-3 py-1.5 font-bold uppercase tracking-wider hover:bg-green-700 shadow-sm">
                                        ✓ ACC
                                    </button>
                                </form>
                                <form action="<?php echo e(route('ijin.reject', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button type="submit"
                                        class="text-xs bg-red-600 text-white px-3 py-1.5 font-bold uppercase tracking-wider hover:bg-red-700 shadow-sm">
                                        ✕ Tolak
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div
                        class="text-center py-10 bg-gray-50 border-2 border-dashed border-gray-200 text-gray-400 italic">
                        Belum ada riwayat perizinan.
                    </div>
                <?php endif; ?>
            </div>

            
            <div id="tampilan-laptop" class="overflow-hidden border border-gray-200 shadow-sm">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-900 text-white">
                        <tr>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <th class="px-4 py-4 text-center w-12">
                                    <span class="text-[10px] font-black text-white uppercase tracking-widest">
                                        PILIH
                                    </span>
                                </th>
                            <?php endif; ?>
                            <th class="px-6 py-4 text-left text-xs font-black uppercase tracking-widest w-40">Tanggal
                                Ijin</th>
                            <th class="px-6 py-4 text-left text-xs font-black uppercase tracking-widest w-48">Nama Guru
                            </th>
                            <th class="px-6 py-4 text-left text-xs font-black uppercase tracking-widest">Keterangan</th>
                            <th class="px-6 py-4 text-left text-xs font-black uppercase tracking-widest w-24">Bukti</th>
                            <th class="px-6 py-4 text-center text-xs font-black uppercase tracking-widest w-32">Status
                            </th>
                            <th class="px-6 py-4 text-center text-xs font-black uppercase tracking-widest w-40">Aksi
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200 ">
                        <?php $__empty_1 = true; $__currentLoopData = $data_ijin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-blue-50 transition duration-150 group ">
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <td class="px-4 py-4 text-center align-middle bg-gray-50 group-hover:bg-blue-50">
                                        <input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>"
                                            class="item-checkbox w-5 h-5 border-2 border-gray-300 text-black focus:ring-black rounded-none">
                                    </td>
                                <?php endif; ?>

                                

                                <td class="px-6 py-4 whitespace-nowrap align-top">
                                    <div class="text-sm font-bold text-gray-900">
                                        <?php echo e(\Carbon\Carbon::parse($item->tanggal)->translatedFormat('d M Y')); ?>

                                    </div>
                                    <?php if($item->jam_mulai && $item->jam_selesai): ?>
                                        <div
                                            class="text-xs text-blue-600 font-bold uppercase mt-1 bg-blue-50 inline-block px-2 py-1 border border-blue-200">
                                            <?php echo e(\Carbon\Carbon::parse($item->jam_mulai)->format('H:i')); ?> -
                                            <?php echo e(\Carbon\Carbon::parse($item->jam_selesai)->format('H:i')); ?>

                                        </div>
                                    <?php else: ?>
                                        <div
                                            class="text-[10px] text-red-600 font-black uppercase mt-1 bg-red-50 inline-block px-2 py-1 border border-red-200 tracking-widest">
                                            1 HARI PENUH
                                        </div>
                                    <?php endif; ?>
                                </td>
                                
                                <td class="px-6 py-4 align-top ">
                                    <div class="text-sm font-bold  text-blue-700 uppercase truncate max-w-xs">
                                        <?php echo e($item->nama_guru); ?>

                                    </div>
                                </td>

                                
                                <td class="px-6 py-4 align-top">
                                    <div
                                        class="text-sm text-gray-600 italic truncate max-w-xs border-l-2 border-gray-300 pl-2">
                                        "<?php echo e($item->alasan); ?>"
                                    </div>
                                </td>

                                
                                <td class="px-6 py-4 align-top">
                                    <?php if($item->bukti_foto): ?>
                                        <a href="<?php echo e(asset('storage/' . $item->bukti_foto)); ?>" target="_blank"
                                            class="text-[10px] font-bold text-indigo-700 hover:underline uppercase">
                                            📷 Lihat
                                        </a>
                                    <?php else: ?>
                                        <span class="text-[10px] text-gray-400 font-bold uppercase ">-</span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="px-6 py-4 align-top text-center">
                                    <?php if($item->status == 'pending'): ?>
                                        <span
                                            class="px-2 py-1 inline-flex text-[10px] leading-5 font-black uppercase tracking-wide border bg-yellow-50 text-yellow-700 border-yellow-300">
                                            Menunggu
                                        </span>
                                    <?php elseif($item->status == 'disetujui'): ?>
                                        <span
                                            class="px-2 py-1 inline-flex text-[10px] leading-5 font-black uppercase tracking-wide border bg-green-50 text-green-700 border-green-300">
                                            Disetujui
                                        </span>
                                    <?php else: ?>
                                        <span
                                            class="px-2 py-1 inline-flex text-[10px] leading-5 font-black uppercase tracking-wide border bg-red-50 text-red-700 border-red-300">
                                            Ditolak
                                        </span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="px-6 py-4 align-top text-center">
                                    <div class="flex flex-col gap-2 items-center">
                                        <a href="<?php echo e(route('ijin.show', $item->id)); ?>"
                                            class="text-xs font-bold text-blue-600 hover:text-black border-b border-blue-600 hover:border-black transition uppercase tracking-wide">
                                            Lihat Detail
                                        </a>

                                        <?php if(Auth::user()->role == 'admin' && $item->status == 'pending'): ?>
                                            <div class="flex gap-1 w-full justify-center">
                                                <form action="<?php echo e(route('ijin.approve', $item->id)); ?>" method="POST"
                                                    class="w-1/2">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit"
                                                        class="w-full bg-green-600 text-white text-[10px] font-bold px-1 py-1 uppercase hover:bg-green-700 transition shadow-sm">
                                                        ACC
                                                    </button>
                                                </form>
                                                <form action="<?php echo e(route('ijin.reject', $item->id)); ?>" method="POST"
                                                    class="w-1/2">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit"
                                                        class="w-full bg-red-600 text-white text-[10px] font-bold px-1 py-1 uppercase hover:bg-red-700 transition shadow-sm">
                                                        TOLAK
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-10 text-center text-gray-400 italic bg-gray-50">
                                    Belum ada data pengajuan ijin.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    
    <form id="bulk-delete-form" action="<?php echo e(route('ijin.bulk_delete')); ?>" method="POST"><?php echo csrf_field(); ?></form>
    <script>
        // Logic Checkbox untuk HP dan Laptop
        const selectAllHP = document.getElementById('select-all');
        const selectAllLaptop = document.getElementById(
            'select-all-desktop'); // Pastikan ID ini ada di checkbox header desktop jika dibuat

        const syncCheckboxes = (checked) => {
            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = checked);
        };

        if (selectAllHP) selectAllHP.addEventListener('change', (e) => syncCheckboxes(e.target.checked));
        // Jika Anda ingin menambahkan select all di desktop header, beri ID 'select-all-desktop' pada checkbox header tsb

        document.getElementById('btn-hapus-massal')?.addEventListener('click', function() {
            let checkboxes = document.querySelectorAll('.item-checkbox:checked');
            if (checkboxes.length === 0) {
                alert('⚠️ Harap pilih minimal satu data untuk dihapus!');
                return;
            }
            if (confirm('❓ Apakah Anda YAKIN ingin menghapus ' + checkboxes.length + ' data terpilih?')) {
                let form = document.getElementById('bulk-delete-form');
                checkboxes.forEach(chk => {
                    let input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'ids[]';
                    input.value = chk.value;
                    form.appendChild(input);
                });
                form.submit();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sekolah-admin\resources\views/ijin/index.blade.php ENDPATH**/ ?>