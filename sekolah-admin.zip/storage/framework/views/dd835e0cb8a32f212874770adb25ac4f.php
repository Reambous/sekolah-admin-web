<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-white min-h-screen font-sans text-gray-900">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">

            
            <div class="bg-white border-2 border-gray-200 p-8 shadow-sm relative">

                
                <div class="border-b-4 border-gray-900 pb-4 mb-8">
                    <h2 class="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-1">
                        Edit Akun Pengguna
                    </h2>
                    <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">
                        Perbarui profil, peran, atau reset password pengguna
                    </p>
                </div>

                <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    
                    <div class="mb-6">
                        <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                            Nama Lengkap
                        </label>
                        <input type="text" name="name" value="<?php echo e($user->name); ?>" required
                            class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold mt-1 uppercase tracking-wide"><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-6">
                        <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                            Email (Login)
                        </label>
                        <input type="email" name="email" value="<?php echo e($user->email); ?>" required
                            class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold mt-1 uppercase tracking-wide"><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-8">
                        <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                            Peran Pengguna (Role)
                        </label>
                        <select name="role"
                            class="w-full bg-gray-50 border-2 border-gray-200 text-gray-900 text-sm font-medium focus:bg-white focus:border-blue-900 focus:ring-0 transition-colors rounded-none px-4 py-3 cursor-pointer">
                            <option value="guru" <?php echo e($user->role == 'guru' ? 'selected' : ''); ?>>Guru / Staf Tata Usaha
                            </option>
                            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Administrator (Akses
                                Penuh)</option>
                        </select>
                    </div>

                    
                    <div class="mt-8 pt-8 border-t-2  bg-gray-50 p-6 border border-gray-200">
                        <h3 class="text-lg font-black text-gray-900 uppercase tracking-tight mb-1">
                            Reset Password
                        </h3>
                        <p class="text-xs text-gray-500 font-bold uppercase tracking-wide mb-4">
                            ⚠ Biarkan kosong jika tidak ingin mengubah password.
                        </p>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                                    Password Baru
                                </label>
                                <input type="password" name="password"
                                    class="w-full bg-white border-2 border-gray-200 text-gray-900 text-sm font-medium focus:border-red-600 focus:ring-0 transition-colors rounded-none px-4 py-3 placeholder-gray-300"
                                    placeholder="Minimal 3 karakter">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-[10px] font-bold mt-1 uppercase tracking-wide">
                                        <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-xs font-black text-gray-900 uppercase tracking-widest mb-2">
                                    Konfirmasi Password
                                </label>
                                <input type="password" name="password_confirmation"
                                    class="w-full bg-white border-2 border-gray-200 text-gray-900 text-sm font-medium focus:border-red-600 focus:ring-0 transition-colors rounded-none px-4 py-3 placeholder-gray-300"
                                    placeholder="Ulangi password">
                            </div>
                        </div>
                    </div>

                    
                    <div class="flex items-center justify-between pt-6 mt-6 border-t-2 border-gray-100">
                        <a href="<?php echo e(route('users.index')); ?>"
                            class="text-xs font-bold text-gray-500 uppercase tracking-widest hover:text-black hover:underline transition">
                            Batal
                        </a>
                        <button type="submit"
                            class="bg-blue-900 text-white px-6 py-3 text-xs font-black uppercase tracking-wider hover:bg-blue-800 transition shadow-sm border-b-4 border-blue-950 hover:border-black transform hover:-translate-y-0.5">
                            Simpan Perubahan
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sekolah-admin\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>