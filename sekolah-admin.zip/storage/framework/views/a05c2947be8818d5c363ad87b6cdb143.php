<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-white min-h-screen font-sans text-gray-900">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            
            <div class="bg-white border-2 border-gray-200 p-8 md:p-10 shadow-sm relative">

                
                <div class="border-b-4 border-gray-900 pb-6 mb-8">
                    <div class="flex justify-between items-start mb-4">
                        <span class="bg-blue-900 text-white text-xs font-bold px-3 py-1 uppercase tracking-widest">
                            Laporan Kegiatan Sarpras
                        </span>

                        
                        <div class="text-right">
                            <div class="text-2xl font-black text-gray-900 leading-none">
                                <?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal)->format('d')); ?>

                            </div>
                            <div class="text-xs font-bold text-gray-500 uppercase">
                                <?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal)->translatedFormat('M Y')); ?>

                            </div>
                        </div>
                    </div>

                    
                    <h1
                        class="text-3xl md:text-4xl font-black text-gray-900 mb-3 uppercase leading-tight tracking-tight break-words">
                        <?php echo e($kegiatan->nama_kegiatan); ?>

                    </h1>

                    
                    <div
                        class="flex flex-wrap items-center gap-4 text-xs font-bold text-gray-500 uppercase tracking-wide truncate">
                        <span class="flex items-center gap-1">
                            <span class="text-blue-700">👤</span> <?php echo e($kegiatan->nama_guru); ?>

                        </span>
                        <span class="text-gray-300">|</span>
                        <span class="flex items-center gap-1">
                            <span class="text-blue-700">🕒</span> Input:
                            <?php echo e(\Carbon\Carbon::parse($kegiatan->created_at)->format('H:i')); ?> WIB
                        </span>
                    </div>
                </div>

                
                <div class="mb-10">
                    <h3 class="text-lg font-black text-gray-900 uppercase mb-4 flex items-center gap-2">
                        <span class="w-2 h-6 bg-yellow-400 inline-block"></span>
                        Detail Keterangan
                    </h3>

                    
                    <div
                        class="bg-gray-50 p-6 border border-gray-200 text-gray-800 text-base md:text-lg leading-relaxed whitespace-pre-line text-justify font-serif break-words">
                        <?php echo e($kegiatan->refleksi ?? 'Tidak ada keterangan detail yang dilampirkan.'); ?>

                    </div>
                </div>

                
                <div
                    class="flex flex-col md:flex-row justify-between items-center pt-6 border-t-2 border-gray-100 gap-4">

                    
                    <a href="<?php echo e(route('sarpras.kegiatan.index')); ?>"
                        class="text-xs font-bold text-gray-900 uppercase tracking-widest hover:text-blue-700 hover:underline transition">
                        &larr; Kembali ke Daftar
                    </a>

                    
                    
                    <div class="flex gap-3 w-full md:w-auto">
                        <?php
                            $isAdmin = Auth::user()->role == 'admin';
                            $isOwner = $kegiatan->user_id == Auth::id();
                            $isApproved = strtolower($kegiatan->status) == 'disetujui';
                        ?>

                        <?php if($isAdmin || ($isOwner && !$isApproved)): ?>
                            <a href="<?php echo e(route('sarpras.kegiatan.edit', $kegiatan->id)); ?>"
                                class="flex-1 md:flex-none text-center bg-yellow-400 text-black px-5 py-2 text-xs font-black uppercase tracking-wider hover:bg-yellow-500 transition shadow-sm">
                                Edit Data
                            </a>

                            <form action="<?php echo e(route('sarpras.kegiatan.destroy', $kegiatan->id)); ?>" method="POST"
                                onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?')"
                                class="flex-1 md:flex-none">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button
                                    class="w-full md:w-auto bg-red-600 text-white px-5 py-2 text-xs font-black uppercase tracking-wider hover:bg-red-700 transition shadow-sm">
                                    Hapus
                                </button>
                            </form>
                        <?php elseif($isOwner && $isApproved): ?>
                            <div
                                class="flex-1 md:flex-none flex items-center justify-center bg-green-50 text-green-700 border-2 border-green-200 px-5 py-2 text-[10px] font-black uppercase tracking-widest shadow-sm">
                                ✓ Laporan Disetujui
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sekolah-admin\resources\views/guru/sarpras/kegiatan/show.blade.php ENDPATH**/ ?>